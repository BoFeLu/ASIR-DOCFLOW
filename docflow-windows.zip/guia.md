# Guía de ejemplo DOCFLOW (Windows)

Este documento fue escrito en **Markdown**.

## Sección 1 — Introducción
Markdown permite escribir documentación técnica limpia y portable.

## Sección 2 — Ejemplo
Comando PowerShell de prueba:
```powershell
Get-Process | Select-Object -First 5
```
