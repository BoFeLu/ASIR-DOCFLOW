# build-doc.ps1
# Script para convertir Markdown a PDF con Pandoc en Windows

Write-Host "[INFO] Iniciando conversión de guia.md a PDF..." -ForegroundColor Cyan

$InputFile = "guia.md"
$DateStamp = Get-Date -Format "yyyyMMdd"
$OutputDir = "output"
$OutputFile = "$OutputDir\guia-$DateStamp.pdf"

if (-not (Test-Path $OutputDir)) {
    New-Item -ItemType Directory -Path $OutputDir | Out-Null
}

pandoc $InputFile -o $OutputFile --pdf-engine=xelatex `
  --toc --toc-depth=2 `
  -V geometry:margin=2.5cm -V linkcolor:blue -V fontsize:11pt

if (Test-Path $OutputFile) {
    Write-Host "[OK] PDF generado correctamente en $OutputFile" -ForegroundColor Green
    Start-Process $OutputFile
} else {
    Write-Host "[ERROR] No se generó el PDF." -ForegroundColor Red
}
