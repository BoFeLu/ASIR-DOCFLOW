# CleanCopy — Módulo de saneamiento textual

## Propósito
Evitar corrupción de formato, caracteres invisibles y errores de codificación al copiar texto desde fuentes no controladas (web, PDF, chat, documentos).

## Uso básico
```bash
./clean-text.sh origen.txt docs/nuevo.md
```

El script:
- Normaliza comillas, guiones, puntos suspensivos y espacios no estándar.
- Elimina líneas vacías excesivas.
- Convierte a **UTF-8 limpio**.
- Garantiza compatibilidad con Pandoc, Git y Markdown renderizado.

## Integración con Makefile
Añade al `Makefile` principal:

```makefile
sanitize:
	@bash modules/CleanCopy/clean-text.sh tmp/origen.txt docs/limpio.md
```

## Buenas prácticas
1. Copiar de la fuente (web, PDF, chat).
2. Pegar en archivo temporal (`tmp/origen.txt`).
3. Ejecutar `make sanitize`.
4. Revisar `docs/limpio.md` antes de incorporarlo a la guía final.
