#!/bin/bash
# CleanCopy v1.0 - Saneamiento y normalización de texto técnico para Docs-as-Code
# Autor: Alberto
# Uso: ./clean-text.sh <origen> <destino>

set -euo pipefail

if [ "$#" -ne 2 ]; then
  echo "Uso: $0 <origen.txt|.md> <destino.md>"
  exit 1
fi

SRC="$1"
DST="$2"

if [ ! -f "$SRC" ]; then
  echo "❌ No se encontró el archivo origen: $SRC"
  exit 2
fi

# Limpieza progresiva
cat "$SRC"   | iconv -f utf-8 -t utf-8 -c   | tr -d '\r'   | sed 's/[[:space:]]*$//'   | sed 's/[“”]/"/g; s/[’‘]/'''/g; s/[–—]/-/g; s/…/.../g;'   | sed 's/  */ /g'   | awk 'NF'   > "$DST"

echo "✅ Archivo limpio guardado en: $DST"
file -i "$DST" | grep -q 'utf-8' && echo "🔣 Codificación UTF-8 verificada."
