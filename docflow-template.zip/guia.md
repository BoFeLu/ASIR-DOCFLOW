# Guía de ejemplo DOCFLOW

Este documento fue escrito en **Markdown**, el formato estándar para documentación técnica.

## Sección 1 — Introducción

Markdown permite escribir texto simple y limpio que luego se puede convertir en PDF, HTML o DOCX.

## Sección 2 — Prueba

Ejemplo de comando en un bloque de código:

```bash
sudo apt install pandoc
```

Fin de la prueba.
