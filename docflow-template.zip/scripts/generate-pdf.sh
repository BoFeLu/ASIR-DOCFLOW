#!/bin/bash
# Script para generar el PDF automáticamente

set -e
INPUT="guia.md"
OUTPUT="output/guia-$(date +%Y%m%d).pdf"

echo "[INFO] Generando PDF..."
pandoc "$INPUT" -o "$OUTPUT" --pdf-engine=xelatex \
  --toc --toc-depth=2 \
  -V geometry:margin=2.5cm -V linkcolor:blue -V fontsize:11pt

echo "[OK] PDF generado correctamente:"
ls -lh "$OUTPUT"
